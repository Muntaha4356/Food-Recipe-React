
import { NavLink } from 'react-router-dom';
import React, {useState, createContext} from 'react';
import { useNavigate } from 'react-router-dom'
import Mainpage from './mainpage';
export const FavoritesContext = createContext();

function Mealcard({detail}){
  
  const navigate = useNavigate();
    console.log(detail);
    const [favoritList, setFavoriteList]= useState([]);
    function handleClickIcon(event, currentitem){
      console.log(currentitem.idMeal)
      console.log(currentitem)
      if (event.target.classList.contains('bx-heart')) {
        event.target.classList.remove('bx-heart');
        event.target.classList.add('bxs-heart');
        event.target.style.color= 'red'
        let CopyFvrtList = [...favoritList];
        const index= CopyFvrtList.findIndex(item=> item.idMeal === currentitem.idMeal)
        if(index=== -1){
          CopyFvrtList.push(currentitem)
          console.log('hp')
          console.log(CopyFvrtList)
        }else {
          CopyFvrtList.splice(index)
        }
        setFavoriteList(CopyFvrtList)
        
        
      }
      else if (event.target.classList.contains('bxs-heart')) {
        event.target.classList.remove('bxs-heart');
        event.target.classList.add('bx-heart');
        
      }
    }
    const gotoFav= ()=>{
      {
        navigate('/favorite', { state: { favoritList } });
      }
    }
  return (
    <>
    {/* <button onClick={gotoFav}>Go To Favorite</button> */}
    <div className='meals'>
      {!detail ? "No Results" : detail.map((curItem) => {
        return (
          <div key={curItem.idMeal} id="container">
            <div className="meal-card">
            <i onClick={(event)=>handleClickIcon(event, curItem)} className='icon bx bx-heart'></i>
              
              <img src={curItem.strMealThumb} alt={curItem.strMeal} />
              <p>{curItem.strMeal}</p>
              <NavLink to={`/${curItem.idMeal}`}><button>View Recipe</button></NavLink>
              
            </div>
          </div>
        );
      })}
    </div>
    <FavoritesContext.Provider value={{ favoritList, setFavoriteList }}>
      <Mainpage/>
    </FavoritesContext.Provider>
    </>
  )
}

export default Mealcard
