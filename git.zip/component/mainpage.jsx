import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useState, useEffect, useContext } from 'react'
import Mealcard from './Mealcard'
// import { FavoritesContext } from './FavoritesContext';
import { FavoritesContext } from './Mealcard'



const Mainpage = () => {
  const { favoritList, setFavoriteList } = useContext(FavoritesContext);
  const navigate = useNavigate();
  const [datafound, setDatafound]= useState(true)
  const  [isLoading, setIsLoading]= useState(true)
  const [dataArray, setDataArray]= useState([])
  const [search, setSearch]= useState(`A`)
  const API= `https://www.themealdb.com/api/json/v1/1/search.php?s=${search}`
  
  function getMeal(){}
    
    const fetchApiData= async (url) => {
      try{
          const response= await fetch(url);
          const data= await response.json();
          setDataArray(data.meals)
          console.log(`data.meals ${data.meals}`)
          data.meals===null ? setDatafound(false): setDatafound(true);
          setIsLoading(false)
          
          return(data)
      } catch(error){
          console.log(error)
      }
  }
  useEffect(()=>{
      fetchApiData(API)
  },[])
  if(isLoading){
      return <>
      <h1>Loading....</h1>
      </>
  }
  const gotoFav= ()=>{
    {
      navigate('/favorite', { state: { favoritList } });
    }
  }
  


  const searchValue= (event)=>{
    setSearch(event.target.value)
  }
  return (
    <>
    <div className='container'>
      <div className="searchBar"> 
        <input type="text" placeholder="Search...." onChange={searchValue}/>
        <button onClick={()=>fetchApiData(API)} className='search'>Search</button>
        <button onClick={gotoFav}>Go To Favorite</button>
      </div>
      

      <div>
          <Mealcard detail={dataArray}/>
      </div>
      
    </div>
    </>
  )
}

export default Mainpage
