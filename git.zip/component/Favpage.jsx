import React from 'react'

const Favpage = () => {
  return (
    <div>
      hello
    </div>
  )
}

export default Favpage
