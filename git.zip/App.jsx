import { Route, Routes} from "react-router-dom";
import Router from "./router";
import Mainpage from "./component/mainpage";
import Mealinfo from "./component/Mealinfo";
import Favpage from "./component/Favpage";
import Mealcard from "./component/Mealcard";

function App() {
  // const router= createBrowserRouter([
  //   {
  //     path: "/",
  //     element:<><Router/><Home/></>
  //   },
  //   {
  //     path:"/login",
  //     element:<><Router/><login/></>
  //   },
  //   {
  //     path:"/about",
  //     element:<><Router/><about/></>
  //   },
  // ])

  return (
    <>
      
        
        <Routes>
          <Route path="/" element={<Mainpage />}/>
          <Route path='/:mealid' element={<Mealinfo/>}/>
          <Route path="/favorite" element={<Favpage/>}/>
          <Route path="/favorite:mealid" element={<Favpage/>}/>
        </Routes>
      
    </>
  )
}

export default App
